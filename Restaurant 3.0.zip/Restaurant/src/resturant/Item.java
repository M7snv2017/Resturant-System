
package resturant;

public class Item {
    String Item;
    int Price;
    int q;

    public Item(String Item, int Price) {
        this.Item = Item;
        this.Price = Price;
    }
     
}
